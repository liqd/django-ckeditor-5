# Changelog

## [0.2.14] - 2025-12-15

### Added
- Aspect ratio buttons (4:3 and 2:1) 
